import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { Observable } from 'rxjs';
import {RestService} from '../rest.service';
import {environment} from '../../environments/environment';
import {Pagination} from '../config';
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  loaded = false;
  pages : any = Pagination.noOfPage;
  cp: number = 1;
  user:any;
  itempageNumber:any;
  // data: any = [
  //   { itemName: 'toothpase' },
  //   { itemName: 'salt' },
  //   { itemName: 'sugar' },
  //   { itemName: 'oil' },
  //   { itemName: 'toothpase' },
  //   { itemName: 'salt' },
  //   { itemName: 'sugar' },
  //   { itemName: 'oil' },
  //   { itemName: 'toothpase' },
  //   { itemName: 'salt' },
  //   { itemName: 'sugar' },
  //   { itemName: 'oil' },
  // ];

  p: number = 1;
  collection: Array<any> = new Array();
  Formdata: any;
  
  constructor(private router:Router,public restService:RestService) { 
    // this.itempageNumber = environment.itemsPerPage;
    console.log("=his.itempageNumber=",this.itempageNumber)
    this.getuserdata();
  }

  ngOnInit(): void {
    setInterval(() => {
      this.loaded = true;
    }, 2000);

     
    // fetch('https://fakestoreapi.com/products')
    // .then(res => res.json())
    // .then(
    //   //json=>console.log(json),
    //   json => this.collection = json
    // )

  }
  logout(formdata: any) {
    // let user = {email:Formdata.email, password:Formdata.password};
    localStorage.clear()
    window.location.href = "/";

  }

  getuserdata(){
    this.restService.getdata().subscribe(res=>{
      console.log("===res",res)
      this.user = res;
    })
  }

}
