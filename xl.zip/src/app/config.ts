export class Pagination{
    public static noOfPage:number = 5;
}