import { Component, OnInit } from '@angular/core';
import * as JsonToXML from "js2xmlparser";
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {



  
  fileToUpload: File | null = null;

  name = "Angular";
  fileUrl: any;
  obj: any = {
    firstName: "John",
    lastName: "Smith",
    dateOfBirth: new Date(1964, 7, 26),
    address: {
      "@": {
        type: "home"
      },
      streetAddress: "3212 22nd St",
      city: "Chicago",
      state: "Illinois",
      zip: 10000
    },
    phone: [
      {
        "@": {
          type: "home"
        },
        "#": "123-555-4567"
      },
      {
        "@": {
          type: "cell"
        },
        "#": "890-555-1234"
      },
      {
        "@": {
          type: "work"
        },
        "#": "567-555-8901"
      }
    ],
    email: "john@smith.com"
  };
  constructor(private sanitizer: DomSanitizer) {
    // console.log(JsonToXML.parse("person", this.obj));

  }

  ngOnInit(): void {
    this.submit();

  }
  submit() {
    let data = JsonToXML.parse("person", this.obj)
    console.log("data", data);
    const blob = new Blob([data], { type: 'application/octet-stream' });

    this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));

  }

   


}
